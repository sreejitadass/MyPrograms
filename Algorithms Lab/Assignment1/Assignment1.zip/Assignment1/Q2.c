#include<stdio.h>
#include<math.h>

int CeilFunction(int x)
{
    return ((int)x)+1;
}

int MinimumHeight(int n)
{
    double minheight=log2(n+1)-1;
    return minheight;
}

int MaximumHeight(int n)
{
    int a=0,b=1,count=1,maxheight=0;
    while(count<n)
    {
        count=a+b+1;
        a=b;
        b=count;
        maxheight++;
    }
    return maxheight;
}

int main()
{
    int n;
    printf("Enter the number of nodes of the AVL tree: ");
    scanf("%d",&n);

    printf("Minimum height of the AVL tree is: %d",MinimumHeight(n));
    printf("\nMaximum height of the AVL tree is: %d",MaximumHeight(n));

    return 0;
}