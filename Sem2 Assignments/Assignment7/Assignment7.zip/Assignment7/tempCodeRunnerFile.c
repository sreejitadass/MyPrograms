            strcpy(arr[j+1],arr[j]);
